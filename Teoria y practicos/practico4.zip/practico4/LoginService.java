package practico4;

public interface LoginService {

	boolean login(String ip, String userName, String password);
	
}