package practico6;

public class Entry {
    public Entry left;
    public Entry right;
    public Integer info;

}

