package practico5;

public class PolinomioException extends RuntimeException {

    public PolinomioException(String s) {
        super(s);
    }  // fin constructor

}  
